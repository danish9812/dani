﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrafficLights
{
    public class TrafficLight
    {
        private List<TrafficElement> _watchers = new List<TrafficElement>();
        private Colour _state;
        public void Subscribe(TrafficElement watcher)
        {
            this._watchers.Add(watcher);
        }
        public Colour State { get { return _state; } set { _state = value; } }
        public void Notify(int ID)
        {
            _watchers[ID].Notice(this.State);
        }
    }
}
