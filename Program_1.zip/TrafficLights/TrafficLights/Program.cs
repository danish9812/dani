﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrafficLights
{
    class Program
    {
        static void Main(string[] args)
        {
            TrafficLight trafficLight = new TrafficLight();
            trafficLight.State = Colour.Green;

            Vehicle vehicle = new Vehicle();
            vehicle.ID = 0;
            trafficLight.Subscribe(vehicle);

            RedLightCamera redLightCamera = new RedLightCamera();
            redLightCamera.ID = 1;
            trafficLight.Subscribe(redLightCamera);

            trafficLight.Notify(vehicle.ID);
            trafficLight.Notify(redLightCamera.ID);



            Console.ReadKey();
        }
    }
}
