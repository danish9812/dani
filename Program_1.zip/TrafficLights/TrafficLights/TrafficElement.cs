﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrafficLights
{
    public abstract class TrafficElement
    {
        public int ID { get; set; }
        public abstract void Notice(Colour state);
    }
}
