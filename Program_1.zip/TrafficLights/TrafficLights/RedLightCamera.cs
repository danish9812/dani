﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrafficLights
{
    public class RedLightCamera : TrafficElement
    {
        public override void Notice(Colour state)
        {
            if (state == Colour.Red)
            {
                Console.WriteLine("Armed");
            }
            else
            {
                Console.WriteLine("Disarmed");
            }
        }
    }
}
