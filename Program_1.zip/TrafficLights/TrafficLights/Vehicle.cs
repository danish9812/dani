﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrafficLights
{
    public class Vehicle : TrafficElement
    {
        public override void Notice(Colour state)
        {
            if (state == Colour.Green)
            {
                Console.WriteLine("Vroom! Vroom!");
            }
            else
            {
                Console.WriteLine("Stopping!");
            }
        }
    }
}
